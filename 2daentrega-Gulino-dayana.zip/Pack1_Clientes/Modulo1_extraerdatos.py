
def obtener_nombre(self):
        return f"Su nombre es {self.nombre}"
    
def obtener_apellidos(self):
        return f"Su apellido es {self.apellidos}"
    
def obtener_DNI(self):
        return f"Su DNI es {self.DNI}"
    
def obtener_nacionalidad(self):
        return f"Su nacionalidad es {self.nacionalidad}"
    
def __str__(self):
        return f"Su nombre completo es {self.nombre} {self.apellidos}, con DNI número: {self.DNI}, identificada en la ciudad de: {self.Ciudad}, nacionalidad {self.nacionalidad}"
