from setuptools import setup

setup(
    name="segunda entrega, Gulino Dayana",
    version="1.0",
    description="Este paquete tiene las funciones y desarrollo de CLIENTES",
    author="Dayana Gulino",
    author_email="Dayanagulino123@gmail.com",
    packages=["Pack1_Clientes"]
)